const { I } = inject();

module.exports = {

    fields: {

        search_query: '#search_query_top',
    },

    buttons: {

        submit_search: '.btn btn-default button-search'
    },

    go() {
        I.amOnPage("/");
    },

    selectGender(gender) {
        I.click(gender, this.popup);
    },

    searchFor(item) {

        I.fillField(this.fields, item);
        I.click(this.buttons.searchSubmit);
    },

}