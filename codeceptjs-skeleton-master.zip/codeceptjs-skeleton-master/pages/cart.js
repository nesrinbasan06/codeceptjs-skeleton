const { I } = inject();

module.exports = {
    buttons: {

        Submit: 'exclusive'
    },
    go() {
        I.amOnPage("http://automationpractice.com/index.php?id_category=11&controller=category");

    },
    goOrder() {
        I.amOnPage("http://automationpractice.com/index.php?controller=order")
    },
    cartFor() {
        I.click(this.buttons.Submit);
    },

}