module.exports = function() {
    return actor({

        login(username, password) {

            this.amOnPage('/');
            this.fillField('nesrinpkts06@gmail.com', username);
            this.fillField('nb123456', password);
            this.click('Login');
        },

        logout() {},

        amSignedIn(username) {

            this.amOnPage('/');
            this.see(username);
        },
    });
}