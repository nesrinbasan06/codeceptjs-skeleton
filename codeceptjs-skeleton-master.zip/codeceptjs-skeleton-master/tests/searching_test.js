Feature('Searching');

Scenario('Search for an item', async(I, homePage) => {

    homePage.go();
    I.seeTitleEquals(homePage.title);
    homePage.searchFor("Blouse");
    I.seeInTitle("Arama Sonucu - automationpractice");
    I.see("\"Blouse\" araması için");
});