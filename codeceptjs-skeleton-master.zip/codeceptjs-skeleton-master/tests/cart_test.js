Feature('AddCart');


Scenario('Cart items', async(I, cartPage) => {

    cartPage.go();
    I.seeTitleEquals(cartPage.title);
    cartPage.cartFor();
    cartPage.goOrder();
    I.seeInTitle("Sepetim - automationpractice");

});